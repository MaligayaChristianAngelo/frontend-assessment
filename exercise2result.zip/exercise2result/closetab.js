
//For closing functionality
<script>
function opentab(tabName) {
  var i;
  var x = document.getElementsByClassName("navtab");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  document.getElementById(tabName).style.display = "block";  
}
</script>